data class Message(
    var sender: String = "",
    var messageContent: String = "",
    var timestamp: String = "",
    var messageId: String = ""
)
