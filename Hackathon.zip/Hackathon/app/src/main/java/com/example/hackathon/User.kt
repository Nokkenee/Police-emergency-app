data class User(
    val FirstName: String,
    val FamilyName: String,
    val SurName: String,
    val BirthDate: String,
    val phoneNumber: String,
    val address: String,
    val idNumber: String,
    val gender: String // "User" or "Officer"
)
